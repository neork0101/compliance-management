#!/bin/bash

# List of services
services=(
    "complianceaudit"
    "compliancecommunication"
    "complianceidentity"
    "compliancemedical"
    "compliancerules"
    "complianceregistry"
    "compliancegateways"
	"integrationadapter"
)

# Stop services
echo "Stopping services..."
for service in "${services[@]}"; do
    if [[ "$service" != "complianceregistry" && "$service" != "compliancegateways" ]]; then
        echo "Stopping $service.service..."
        sudo systemctl stop "$service.service"
    fi
done

# Stop complianceregistry and compliancegateways last
echo "Stopping compliancegateways.service..."
sudo systemctl stop "compliancegateways.service"
echo "Stopping complianceregistry.service..."
sudo systemctl stop "complianceregistry.service"


# Start services
echo "Starting complianceregistry.service..."
sudo systemctl start "complianceregistry.service"
sleep 10

echo "Starting compliancegateways.service..."
sudo systemctl start "compliancegateways.service"
sleep 10

echo "Starting remaining services..."
for service in "${services[@]}"; do
    if [[ "$service" != "complianceregistry" && "$service" != "compliancegateways" ]]; then
        echo "Starting $service.service..."
        sudo systemctl start "$service.service"
    fi
done

echo "All services have been managed successfully!"
