#!/bin/bash

# Directory containing the logs
LOG_DIR="/root/webapp"
# Number of old files to keep (excluding the current one)
KEEP_FILES=1  # Changed to 1 to keep only current and last version

# Function to cleanup log files with specific pattern
cleanup_logs() {
    local pattern=$1
    echo "Cleaning up files matching pattern: $pattern"
    
    # Exclude .jar files and list files matching pattern, sorted by date (newest first)
    find "$LOG_DIR" -name "$pattern" -not -name "*.jar" -type f -printf '%T@ %p\n' | \
    sort -nr | \
    cut -d' ' -f2- | \
    tail -n +$((KEEP_FILES + 2)) | \
    while read file; do
        echo "Removing: $file"
        rm -f "$file"
    done
}

# Clean up all log files (both .log and .gz)
cleanup_logs "audit-*[0-9].log"
cleanup_logs "audit-*.gz"
cleanup_logs "communication-*[0-9].log"
cleanup_logs "communication-*.gz"
cleanup_logs "compliance-gateways*.log*"
cleanup_logs "compliance-*.gz"
cleanup_logs "identity-management*.log*"
cleanup_logs "identity-*.gz"
cleanup_logs "integration-adapter*.log*"
cleanup_logs "integration-*.gz"
cleanup_logs "medical-trial-management*.log*"
cleanup_logs "medical-*.gz"
cleanup_logs "rule-management*.log*"
cleanup_logs "rule-*.gz"

# Clean up service logs (keeping only the most recent)
cleanup_logs "*-service.log"